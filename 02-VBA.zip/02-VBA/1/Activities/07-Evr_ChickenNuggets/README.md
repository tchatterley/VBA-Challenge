# Looping on through

Now it's your chance to see how quickly we can create data utilizing the power of a computer and `for` loops!

## Instructions

* Create a `for` loop that will produce the following example. The lines signify new cells.

|  A | B  |  C |
|:---:|:---:|:---:|
| I will eat | 11 | Chicken Nuggets |
| I will eat | 12 | Chicken Nuggets |
| I will eat | 13 | Chicken Nuggets |
| I will eat | 14 | Chicken Nuggets |
| I will eat | 15 | Chicken Nuggets |
| I will eat | 16 | Chicken Nuggets |
| I will eat | 17 | Chicken Nuggets |
| I will eat | 18 | Chicken Nuggets |
| I will eat | 19 | Chicken Nuggets |
| I will eat | 20 | Chicken Nuggets |

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.

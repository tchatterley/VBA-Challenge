# Choose Your Story

## Instructions

* Create a simple Excel workbook and VBA macro in which a user is provided a single button to click. Based on the number they provide in a text box above, a different message box will appear.

  * If the user enters a value of 1, display: “You choose to enter the wooded forest of doom!”

  * If the user enters a value of 2, display: “You choose to enter the fiery volcano of doom!”

  * If the user enters a value of 3, display: “You choose to enter the terrifying jungle of doom!”

  * If the user enters a value of 4, display a similar custom message.

  * If the user enters anything else, display: “Try following directions”
  
---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.
